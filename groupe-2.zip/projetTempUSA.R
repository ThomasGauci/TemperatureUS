#�tats choisis: Californie, Louisiana, Ohio, Minnesota, Montana
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
#List all CSV Files in a Directory/Folder
ech_80_14_files = list.files("CSV/Echantillon 1", pattern="*.csv", full.names=TRUE)
ech_15_19_files = list.files("CSV/Echantillon 2", pattern="*.csv", full.names=TRUE)

#-------PREMIER ECHANTILLON: 1980 - 2014 -------#
#On cr�e le premier �chantillon
data_tmp <- lapply(ech_80_14_files, function(i){
        read.csv(i, header=FALSE, skip=4)
})

# V17: moyenne; V18: max; V25: Nom de l'Etat;
df <- do.call(rbind.data.frame, data_tmp)
head(df)
#S�lection des colonnes pertinentes
data_80_14 <- data_80_14[,c("V25", "V18", "V17")]
#S�lection des donn�es des Etats qui nous int�ressent
data_80_14=subset(df, V25=="California" | V25=="Louisiana" | V25=="Ohio" | V25=="Minnesota" | V25=="Montana")
#Renommage des colonnes
colnames(data_80_14)[1] <- "�tat"
colnames(data_80_14)[2] <- "Temp�rature maximale"
colnames(data_80_14)[3] <- "Temp�rature moyenne"

#Comme la moyenne est une moyenne arithm�tique, on peut d�terminer
#la temp�rature minimale � partir de la moyenne et de la temp�rature
#maximale
#Moy = (Min+Max)/2
#2*Moy = Min+Max
#2*Moy-Max = Min
temp_minimale=2*data_80_14$`Temp�rature moyenne`-data_80_14$`Temp�rature maximale`
data_80_14$temp_minimale=temp_minimale

#Calcul de la moyenne et de l'�cart type, pour cet �chantillon

#Moyenne de la temp�rature max
moy_max_1 <- mean(data_80_14$`Temp�rature maximale`)
#Ecart type sur la temp�rature max
sigma_tmp <- 0
for(j in 1:nrow(data_80_14))
{
 sigma_tmp <- sigma_tmp + (moy_max_1-data_80_14$`Temp�rature maximale`[j])^2
        
}
#�cart-type = racine carr� de la variance
sigma_max_1 <- sqrt(sigma_tmp/(nrow(data_80_14)-1))


#Moyenne de la temp�rature moyenne
moy_moyenne_1 <- mean(data_80_14$`Temp�rature moyenne`)

#Ecart type sur la temp�rature moyenne
sigma_tmp <- 0
for(j in 1:nrow(data_80_14))
{
        sigma_tmp <- sigma_tmp+(moy_moyenne_1-data_80_14$`Temp�rature moyenne`[j])^2
        
}
sigma_moy_1 <- sqrt(sigma_tmp/(nrow(data_80_14)-1))

#Moyenne de la temp�rature minimale
moy_min_1 <- mean(data_80_14$`temp_minimale`)

#Ecart type sur la temp�rature minimale
sigma_tmp <- 0
for(j in 1:nrow(data_80_14))
{
        sigma_tmp <- sigma_tmp+(moy_min_1-data_80_14$`temp_minimale`[j])^2
        
}
sigma_min_1 <- sqrt(sigma_tmp/(nrow(data_80_14)-1))

#-------DEUXIEME ECHANTILLON: 2015 - 2019 -------#
#On fait pareil avec le deuxi�me �chantillon

data_tmp <- lapply(ech_15_19_files,function(i){
        read.csv(i, header=FALSE, skip=4)
})

# V17 moyenne V18 max V25 Nom de l'Etat
df <- do.call(rbind.data.frame, data_tmp)
head(df)
data_15_19=subset(df, V25=="California" | V25=="Louisiana" | V25=="Ohio" | V25=="Minnesota" | V25=="Montana")
data_15_19 <- data_15_19[,c("V25", "V18", "V17")]
colnames(data_15_19)[1] <- "�tat"
colnames(data_15_19)[2] <- "Temp�rature maximale"
colnames(data_15_19)[3] <- "Temp�rature moyenne"

#Comme la moyenne est une moyenne arithm�tique, on peut d�terminer
#la temp�rature minimale � partir de la moyenne et de la temp�rature
#maximale
temp_minimale=2*data_15_19$`Temp�rature moyenne`-data_15_19$`Temp�rature maximale`
data_15_19$temp_minimale=temp_minimale

#Moyenne de la temp�rature max
moy_max_2 <- mean(data_15_19$`Temp�rature maximale`)
#Ecart type sur la temp�rature max
sigma_tmp <- 0
for(j in 1:nrow(data_15_19))
{
        sigma_tmp <- sigma_tmp + (data_15_19$`Temp�rature maximale`[j]-moy_max_2)^2
        
}
sigma_max_2 <- sqrt(sigma_tmp/(nrow(data_15_19)-1))
print(data_15_19$`Temp�rature maximale`)

#Moyenne de la temp�rature moyenne
moy_moyenne_2 <- mean(data_15_19$`Temp�rature moyenne`)

#Ecart type sur la temp�rature moyenne
sigma_tmp <- 0
for(j in 1:nrow(data_15_19))
{
        sigma_tmp <- eval.parent(substitute(sigma_tmp+(moy_moyenne_1-data_15_19$`Temp�rature moyenne`[j])^2))
        
}
sigma_moy_2 <- sqrt(sigma_tmp/(nrow(data_15_19)-1))

#Moyenne de la temp�rature minimale
moy_min_2 <- mean(data_15_19$`temp_minimale`)

#Ecart type sur la temp�rature minimale
sigma_tmp <- 0
for(j in 1:nrow(data_15_19))
{
        sigma_tmp <- sigma_tmp+(moy_min_1-data_15_19$`temp_minimale`[j])^2
        
}
sigma_min_2 <- sqrt(sigma_tmp/(nrow(data_15_19)-1))

#----------- COMPARAISON DES MOYENNES ----------------#
print("Moyennes pour l'�chantillon 1: ")
print(paste0("Temp�rature minimale: ", moy_min_1))
print(paste0("Temp�rature moyenne: ", moy_moyenne_1))
print(paste0("Temp�rature maximale: ", moy_max_1))

print("Moyennes pour l'�chantillon 2: ")
print(paste0("Temp�rature minimale: ", moy_min_2))
print(paste0("Temp�rature moyenne: ", moy_moyenne_2))
print(paste0("Temp�rature maximale: ", moy_max_2))

#---------------- COMPARAISON DES ECARTS TYPE ----------#
print("Ecarts type pour l'�chantillon 1: ")
print(paste0("Temp�rature minimale: ", sigma_min_1))
print(paste0("Temp�rature moyenne: ", sigma_moy_1))
print(paste0("Temp�rature maximale: ", sigma_max_1))

print("Ecarts type pour l'�chantillon 2: ")
print(paste0("Temp�rature minimale: ", sigma_min_2))
print(paste0("Temp�rature moyenne: ", sigma_moy_2))
print(paste0("Temp�rature maximale: ", sigma_max_2))

sigma_essai=sd(data_15_19$`Temp�rature maximale`)
print(paste0("ESSAI FONCTION SD ", sigma_essai))
      print(sigma_essai)


#---------- Partie avec les graphes -------------#
temp_maximale=data_80_14$`Temp�rature maximale`
temp_moy=data_80_14$`Temp�rature moyenne`

#Corr�lation entre les 3 variables de temp�rature, pour l'�chantillon 1
plot(data_80_14$temp_minimale,
     type="l",
     # 2.
     main="Corr�lation entre les 3 variables statistiques",
     # 3.
     xlab="Nombre de mesures",
     ylab="Temp�rature (Farhenheit)",
     col="blue"
)
lines(temp_maximale, type="l",col="red")
lines(temp_moy, type="l",col="green")
legend("bottomleft", legend = c("Temp�rature minimale", "Temp�rature moyenne", "Temp�rature maximale"),
       col = c("blue", "green", "red"), lty = 1:2, cex = 0.8)

#Corr�lation entre les 3 variables de temp�rature, pour l'�chantillon 2
plot(data_15_19$temp_minimale,
     type="l",
     # 2.
     main="Corr�lation entre les 3 variables statistiques",
     # 3.
     xlab="Nombre de mesures",
     ylab="Temp�rature (Farhenheit)",
     col="blue"
)
lines(data_15_19$`Temp�rature maximale`, type="l",col="red")
lines(data_15_19$`Temp�rature moyenne`, type="l",col="green")
legend("bottomleft", legend = c("Temp�rature minimale", "Temp�rature moyenne", "Temp�rature maximale"),
       col = c("blue", "green", "red"), lty = 1:2, cex = 0.8)

#Comparaison des moyennes entre les 2 �chantillons
plot(moy_min_1,
     type="b",
     # 2.
     main="Comparaison des moyennes entre les 2 �chantillons",
     # 3.
     ylab="Temp�rature (Farhenheit)",
     col="red",
     ylim = c(10, 70)
)

lines(moy_moyenne_1, type="b",col="red")
lines(moy_max_1, type="b",col="red")
lines(moy_min_2, type="b",col="blue")
lines(moy_moyenne_2, type="b",col="blue")
lines(moy_max_2, type="b",col="blue")
legend("bottomleft", legend = c("Moyennes sur �chantillon 1", "Moyennes sur �chantillon 2"),
       col = c("red", "blue"), lty = 1:2, cex = 0.8)

#Comparaison des �carts type entre les 2 �chantillons
plot(sigma_min_1,
     type="b",
     # 2.
     main="Comparaison des �carts type entre les 2 �chantillons",
     # 3.
     ylab="Temp�rature (Farhenheit)",
     col="red",
     ylim = c(10, 20)
)

lines(sigma_moy_1, type="b",col="red")
lines(sigma_max_1, type="b",col="red")
lines(sigma_min_2, type="b",col="blue")
lines(sigma_moy_2, type="b",col="blue")
lines(sigma_max_2, type="b",col="blue")
legend("bottomleft", legend = c("Moyennes sur �chantillon 1", "Moyennes sur �chantillon 2"),
       col = c("red", "blue"), lty = 1:2, cex = 0.8)